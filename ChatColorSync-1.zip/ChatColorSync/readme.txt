
ChatColorSync

This add-on synchronizes your chat channel colors between all your
characters. This add-on runs in the background and synchronizes
all changes you apply to your channel between all your other
characters.

