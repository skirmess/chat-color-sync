
ChatColorSync

This add-on synchronizes your chat channel colors between all your
characters. This add-on runs in the background and synchronizes
all changes you apply to your channel between all your other
characters.

*** Changelog

Version 13
 * Updated TOC for WoW 6.1.0

Version 12
 * Take the list of existing channels from the color menu.

Version 11
 * Updated TOC for WoW 5.2.0

Version 10
 * Updated for MoP.

Version 9
 * Updated TOC for WoW 4.3.0

Version 8
 * Updated TOC for WoW 4.0.1

Version 7
 * Replaced static list of channels to sync with a function that gets all channels available and syncs all but REPLY.

Version 6
 * Updated TOC for WoW 3.3
 * Added the new channels ACHIEVEMENT, GUILD_ACHIEVEMENT, PARTY_LEADER, TARGETICONS to the sync list.

Version 5
 * Sync the class color configuration of the chat channels.
 * Code cleanup.
 * No longer use an XML file.

Version 4
 * Updated TOC for WoW 3.2
 * Added license information
 * Added link to project main page at
 * http://code.google.com/p/chat-color-sync/

Version 3
 * Updated TOC for WoW 3.1.2

Version 2
 * Updated TOC for WoW 3.0.2
